package com.AbajoDelReloj.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="users")
public class Usuario {

	@Id //especificamos que nuestra llave primaria es el campo id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) //Indicamos a JAVA que vamos a utilizar una estrategia de generacion
														//de valores de indentidad de la base de datos (para generar valores
														//unicos e incrementables para nuestras llaves primarias)
	
	/*
		Especificamos que el campo donde se aplica la estrategia de generacion de valores autoincremetables es
		una columa llamada id, unica y no nula
	 */
	@Column(name="idusers", unique=true, nullable=false)
	
	//Atributos
	private Long IdUsers;		//class wrapper
	//@column name
	private String name;
	//@columna last_name
	private String last_name;
	//@column user_name
	private String user_name;
	//@column correo
	private String correo;
	//@column user_name
	private String password;
	//@column precion
	private Long telephone;	//o double?

	//Constructor vacio
	public Usuario() {
		
	}//constructor vacio
	
	
	//Constructores
	public Usuario(Long idUsers, String name, String last_name, String user_name, String correo, String password, Long telephone) {
		this.IdUsers = idUsers;
		this.name = name;
		this.last_name = last_name;
		this.user_name = user_name;
		this.correo = correo;
		this.password = password;
		this.telephone = telephone;
	}


	//Getters y Setters
	public Long getIdUsers() {
		return IdUsers;
	}


	public void setIdUsers(Long idUsers) {
		IdUsers = idUsers;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getLast_name() {
		return last_name;
	}


	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}


	public String getUser_name() {
		return user_name;
	}


	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Long getTelephone() {
		return telephone;
	}


	public void setTelephone(Long telephone) {
		this.telephone = telephone;
	}

	//toString

	@Override
	public String toString() {
		return "Usuario [IdUsers=" + IdUsers + ", name=" + name + ", last_name=" + last_name + ", user_name="
				+ user_name + ", correo=" + correo + ", password=" + password + ", telephone=" + telephone + "]";
	}
	
}
