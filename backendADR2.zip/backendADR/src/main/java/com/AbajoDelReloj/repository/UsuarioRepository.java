package com.AbajoDelReloj.repository;

public class UsuarioRepository {

}
