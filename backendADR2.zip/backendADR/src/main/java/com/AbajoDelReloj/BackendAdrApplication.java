package com.AbajoDelReloj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendAdrApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendAdrApplication.class, args);
	}

}
